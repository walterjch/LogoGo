var dir_391569755103fa558e0f03e8eac218cc =
[
    [ "AssemblyInfo.cs", "_assembly_info_8cs.html", null ],
    [ "Resources.Designer.cs", "_resources_8_designer_8cs.html", null ],
    [ "Settings.Designer.cs", "_settings_8_designer_8cs.html", null ]
];