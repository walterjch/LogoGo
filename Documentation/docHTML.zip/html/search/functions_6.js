var searchData=
[
  ['polygone_142',['Polygone',['../class_w_f___logo_go_1_1_polygone.html#a0de7aeeda284b0e7685df52b1f2a6cb2',1,'WF_LogoGo.Polygone.Polygone(Form parent, int calque)'],['../class_w_f___logo_go_1_1_polygone.html#a2252030d4e3121968165a5b3b23c3461',1,'WF_LogoGo.Polygone.Polygone(SpriteSerializable s, Form parent)']]]
];
