var searchData=
[
  ['logo_141',['Logo',['../class_w_f___logo_go_1_1_logo.html#a94edf81facbc2075517fa4a1ab32ef85',1,'WF_LogoGo.Logo.Logo(Form parent)'],['../class_w_f___logo_go_1_1_logo.html#a40905eb16a39508bb02ab87111d09982',1,'WF_LogoGo.Logo.Logo()']]]
];
