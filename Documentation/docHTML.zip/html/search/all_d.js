var searchData=
[
  ['xmldeserialize_83',['XMLDeserialize',['../class_w_f___logo_go_1_1_logo.html#a17971a941823eda311222fe51ea67176',1,'WF_LogoGo::Logo']]]
];
