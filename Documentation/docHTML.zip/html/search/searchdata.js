var indexSectionsWithContent =
{
  0: "acdefilnprstwx",
  1: "cflprst",
  2: "w",
  3: "acflprstw",
  4: "acdeflprstx",
  5: "l",
  6: "aceilnprst"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "namespaces",
  3: "files",
  4: "functions",
  5: "variables",
  6: "properties"
};

var indexSectionLabels =
{
  0: "All",
  1: "Classes",
  2: "Namespaces",
  3: "Files",
  4: "Functions",
  5: "Variables",
  6: "Properties"
};

