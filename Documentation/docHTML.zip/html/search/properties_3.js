var searchData=
[
  ['idtype_165',['IdType',['../class_w_f___logo_go_1_1_sprite.html#a08497538042474ac42214ccba525da95',1,'WF_LogoGo.Sprite.IdType()'],['../class_w_f___logo_go_1_1_sprite_serializable.html#af80daa5fe6174bbbb823c5af8f17afaa',1,'WF_LogoGo.SpriteSerializable.IdType()']]]
];
