var class_w_f___logo_go_1_1_sprite_serializable =
[
    [ "SpriteSerializable", "class_w_f___logo_go_1_1_sprite_serializable.html#acfe9c7be27d7b4fe7a5f518dd37ee593", null ],
    [ "AttribuerValeursProprietes", "class_w_f___logo_go_1_1_sprite_serializable.html#a0e444c4f9d6345f01ab96efbb8bbf9bc", null ],
    [ "EnSprite", "class_w_f___logo_go_1_1_sprite_serializable.html#a8d2a7d10a473513cb34e52c9e93e1a45", null ],
    [ "Couleur", "class_w_f___logo_go_1_1_sprite_serializable.html#ae80f648eb49e6655d6a7042715b6dbcb", null ],
    [ "EpaisseurPen", "class_w_f___logo_go_1_1_sprite_serializable.html#ab9d242143c76087769e1e7fee90039b2", null ],
    [ "IdType", "class_w_f___logo_go_1_1_sprite_serializable.html#af80daa5fe6174bbbb823c5af8f17afaa", null ],
    [ "Location", "class_w_f___logo_go_1_1_sprite_serializable.html#a5eb48c6a972367fdd76cc022449419ce", null ],
    [ "Nom", "class_w_f___logo_go_1_1_sprite_serializable.html#add5bb378aa5a81f1a0a28b8c7f614dd0", null ],
    [ "NomPolice", "class_w_f___logo_go_1_1_sprite_serializable.html#a3db2133c1f19f5b22399f60e781ccbe6", null ],
    [ "NumeroCalque", "class_w_f___logo_go_1_1_sprite_serializable.html#a37e665913d97cef0aa143c8ed52df94c", null ],
    [ "ProfondeurParCalque", "class_w_f___logo_go_1_1_sprite_serializable.html#af9efff176146d15603049c8e257e9887", null ],
    [ "Remplir", "class_w_f___logo_go_1_1_sprite_serializable.html#a93cb8628c80d1e8dc3b69ab7152b157f", null ],
    [ "Size", "class_w_f___logo_go_1_1_sprite_serializable.html#a0f9d36d72024cfb42c89d8466083b535", null ],
    [ "TaillePolice", "class_w_f___logo_go_1_1_sprite_serializable.html#ab89506ac46846fb820677a37eaf71e40", null ],
    [ "TexteAEcrire", "class_w_f___logo_go_1_1_sprite_serializable.html#a17bd022f0a9ed1ebf3d47a59f8c26aca", null ],
    [ "Trace", "class_w_f___logo_go_1_1_sprite_serializable.html#ad85eb80e018a7abfabb924fd7c5efea4", null ]
];