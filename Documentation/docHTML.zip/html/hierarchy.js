var hierarchy =
[
    [ "Form", null, [
      [ "WF_LogoGo.frmCreerPolygone", "class_w_f___logo_go_1_1frm_creer_polygone.html", null ],
      [ "WF_LogoGo.frmExporterLogo", "class_w_f___logo_go_1_1frm_exporter_logo.html", null ],
      [ "WF_LogoGo.frmLogoGo", "class_w_f___logo_go_1_1frm_logo_go.html", null ]
    ] ],
    [ "WF_LogoGo.Logo", "class_w_f___logo_go_1_1_logo.html", null ],
    [ "PictureBox", null, [
      [ "WF_LogoGo.Sprite", "class_w_f___logo_go_1_1_sprite.html", [
        [ "WF_LogoGo.Carre", "class_w_f___logo_go_1_1_carre.html", null ],
        [ "WF_LogoGo.Polygone", "class_w_f___logo_go_1_1_polygone.html", null ],
        [ "WF_LogoGo.Rond", "class_w_f___logo_go_1_1_rond.html", null ],
        [ "WF_LogoGo.Texte", "class_w_f___logo_go_1_1_texte.html", null ],
        [ "WF_LogoGo.Triangle", "class_w_f___logo_go_1_1_triangle.html", null ]
      ] ]
    ] ],
    [ "WF_LogoGo.Sprites", "class_w_f___logo_go_1_1_sprites.html", null ],
    [ "WF_LogoGo.SpriteSerializable", "class_w_f___logo_go_1_1_sprite_serializable.html", null ],
    [ "WF_LogoGo.SpritesSerializables", "class_w_f___logo_go_1_1_sprites_serializables.html", null ]
];